# Smart ATS Frontend (React + Vite)

A responsive demo Applicant Tracking System for HR Tech / SaaS. Includes role switching for Admin, HR Staff, and Candidate; dashboard analytics; job CRUD; candidate search/filter/status changes; interview scheduling and completion; offer status tracking; onboarding checklists; CSV export; and localStorage persistence.

## Requirements
- Node.js 18+ (Node.js 20+ recommended)
- npm

## Run locally
1. Extract the `smart-ats` folder.
2. Open a terminal in `smart-ats/frontend`.
3. Run `npm install`
4. Run `npm run dev`
5. Open the local URL printed by Vite (usually `http://localhost:5173`).

## Build for production
From `smart-ats/frontend`, run `npm run build`. The production files are created in `frontend/dist`.

## Demo notes
- Use the role selector in the top-right to switch between **HR Staff**, **Admin**, and **Candidate** views.
- Use **Create job**, candidate stage selectors, **Schedule interview**, offer status selectors, onboarding checkboxes, and **Export** to test interactions.
- Demo records are saved in browser localStorage under `smartats_*` keys. Clearing browser storage resets the demo records to their seed values.
- This is frontend-only. It does not provide real authentication, server-side permissions, email delivery, file uploads, or a database. Connect an API/backend before using it with real candidate data.
